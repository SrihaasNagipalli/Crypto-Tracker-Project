import React from 'react'
import Headerindex from '../compontes/common/Header/Headerindex'
import SelectCoin from '../compontes/Comaprepage/Seletctcoin'
import ContactUs from '../compontes/Comaprepage/Comparing'

const Compare = () => {
  return (
    <div>
      <Headerindex/>
      <SelectCoin/>
      <ContactUs/>
    </div>
  )
}

export default Compare