import React from 'react'

const Watchlist = () => {
  return (
    <div>Watchlist</div>
  )
}

export default Watchlist